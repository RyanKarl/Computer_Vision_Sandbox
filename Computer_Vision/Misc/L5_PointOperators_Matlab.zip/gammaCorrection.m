% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame
% _________________________
% Adam Czajka, January 2016

clear all

% read a parrot image
% and transform it to gray scale
image = rgb2gray(imread('parrot.bmp'));

% make an intensity a double-precision 
% number in the range [0,1]
inputImage = double(image)/...
             double(max(image(:)));

% plot gamma-corrected images
for gamma = 0.5:0.1:2.5
    
    outputImage = inputImage.^(1/gamma);
    
    figure(1)
    imshow(outputImage)

    disp(['gamma = ' num2str(gamma)])
    pause

end
