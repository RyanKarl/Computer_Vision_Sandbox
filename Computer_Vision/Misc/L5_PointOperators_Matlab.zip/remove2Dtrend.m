% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame
% _________________________
% Adam Czajka, January 2016

clear all
close all

% read an iris image and convert it
% to double precision
image = double(imread('iris.png'));

% get its size and prepare a mesh grid
[rows,cols] = size(image);
[X, Y] = meshgrid(1:cols,1:rows);
Xvec = X(:); Yvec = Y(:); 
Zvec = image(:);

% use least squares minimization
% to find a linear approximation
% of the image brigthness
f = fit([Xvec,Yvec], Zvec, 'poly11');
trendPlane = f.p00 + f.p10 * X + f.p01 * Y;

% calculate detrende version of our image;
% note addition of a global mean (!)
deTrendedImage = ...
    image - trendPlane + mean(trendPlane(:));

% show the results
figure(1)
subplot(2,2,1)
imshow(uint8(image))
title('Original image')

subplot(2,2,2)
imshow(uint8(deTrendedImage))
title('Detrended image')

subplot(2,2,3)
imshow(uint8(trendPlane))
title('Estimated trend')

subplot(2,2,4)
title('Original image and estimated trend')
hold on
mesh(trendPlane,zeros(rows,cols))
mesh(image)
view([130 30])
hold off