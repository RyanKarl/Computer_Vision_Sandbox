% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame
% _________________________
% Adam Czajka, January 2016

clear all

% read input images
image1 = imread('parrot.bmp');
image2 = imread('bird.bmp');

% make an alpha blending
frame = 1;
for alpha=0:0.02:1
    
    outputImage = ...
        alpha*image1 + (1-alpha)*image2;
    
    F(frame) = im2frame(outputImage);
    frame = frame + 1;
end

% play ...
figure(1)
axis off tight
movie(F)