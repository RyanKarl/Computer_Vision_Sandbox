% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame
% ___________________________
% Adam Czajka, September 2017

clear all
close all

% read an iris image and convert it
% to double precision
image = rgb2gray(imread('cat.bmp'));

% calculate new image 
% with equalized histogram
imageEQ = histeq(image,1024);

% calculate empirical cumulative
% distribution function for both images
[F,X] = ecdf(image(:));
F = [0 F.' 1];
X = [0 X.' 255];

[Feq,Xeq] = ecdf(imageEQ(:));
Feq = [0 Feq.' 1];
Xeq = [0 Xeq.' 255];

% and show the resutls
figure(1)
title('Original image')
histogram(image(:),32)

figure(2)
title('Equalized image')
histogram(imageEQ(:),32)

figure(3)
title('Empirical CDF for original image')
hold on
set(plot(X,F),'LineWidth',4)
axis([0 255 0 1])
grid on
hold off

figure(4)
title('Empirical CDF for equalized image')
hold on
set(plot(Xeq,Feq),'LineWidth',4)
axis([0 255 0 1])
grid on
hold off
