% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame
% _________________________
% Adam Czajka, January 2016

clear all

% read a parrot image
% and transform it to gray scale
image = rgb2gray(imread('parrot.bmp'));

% make an intensity a double-precision 
% number in the range [0,1]
inputImage = double(image)/...
             double(max(image(:)));

% make some affine transformation
outputImage = 1.8 * inputImage - 0.2;

% show images
figure(1)
imshow(inputImage)
figure(2)
imshow(outputImage)



