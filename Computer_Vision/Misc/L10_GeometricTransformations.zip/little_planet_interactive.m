function varargout = little_planet_interactive(varargin)
% LITTLE_PLANET_INTERACTIVE MATLAB code for little_planet_interactive.fig
%      LITTLE_PLANET_INTERACTIVE, by itself, creates a new LITTLE_PLANET_INTERACTIVE or raises the existing
%      singleton*.
%
%      H = LITTLE_PLANET_INTERACTIVE returns the handle to a new LITTLE_PLANET_INTERACTIVE or the handle to
%      the existing singleton*.
%
%      LITTLE_PLANET_INTERACTIVE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LITTLE_PLANET_INTERACTIVE.M with the given input arguments.
%
%      LITTLE_PLANET_INTERACTIVE('Property','Value',...) creates a new LITTLE_PLANET_INTERACTIVE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before little_planet_interactive_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to little_planet_interactive_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help little_planet_interactive

% Last Modified by GUIDE v2.5 22-Feb-2016 21:40:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @little_planet_interactive_OpeningFcn, ...
                   'gui_OutputFcn',  @little_planet_interactive_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before little_planet_interactive is made visible.
function little_planet_interactive_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to little_planet_interactive (see VARARGIN)

% Choose default command line output for little_planet_interactive
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

I = imread('./panoramas/pan5.jpg');

% hardcode intial values of sliders, bad, very bad!
handles.lon = 100; 
handles.lat = 100;
handles.z = 16;
[rows, cols, ndims] = size(I);
handles.rows = rows;
handles.cols = cols;
handles.ndims = ndims;
[handles.X_tar, handles.Y_tar] = meshgrid(1:handles.cols, 1:handles.rows);
handles.I = double(I);
handles.I_transformed = double(zeros(handles.rows, handles.cols, handles.ndims));
guidata(hObject, handles);
updateUI(handles);

% UIWAIT makes little_planet_interactive wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = little_planet_interactive_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function lon_slider_Callback(hObject, eventdata, handles)
    set(handles.lon_text, 'String', num2str(get(handles.lon_slider, 'Value')));
    updateUI(handles);
    
% hObject    handle to lon_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function lon_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lon_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function lat_slider_Callback(hObject, eventdata, handles)
    set(handles.lat_text, 'String', num2str(get(handles.lat_slider, 'Value')));
    updateUI(handles);
    
% hObject    handle to lat_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function lat_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lat_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function z_slider_Callback(hObject, eventdata, handles)
    set(handles.z_text, 'String', num2str(get(handles.z_slider, 'Value')));
    updateUI(handles);
    
% hObject    handle to z_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function z_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to z_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function updateUI(handles)
    handles.lon = get(handles.lon_slider, 'Value');
    handles.lat =get(handles.lat_slider, 'Value');
    handles.z = get(handles.z_slider, 'Value');
    if handles.z == 0
        handles.z = 1;
    end
    R = handles.cols / handles.z;
    phi0 = handles.lat * pi / 180.0 - pi / 2;
    lambda0 = handles.lon * pi / 180.0;
    X = handles.X_tar - handles.cols / 2.0;
    Y = handles.Y_tar - handles.rows / 2.0;
    r = sqrt(X.^2 + Y.^2);
    c = 2 * atan((r/2) ./ R);

    map_lat = pi / 2.0 + asin(cos(c) * sin(phi0) + Y .* sin(c) * cos(phi0) ./ r);
    map_lon = lambda0 + atan2(X .* sin(c), r .* cos(phi0) .* cos(c) - Y .* sin(phi0) .* sin(c));

    map_lon = mod(map_lon + pi, 2 * pi);

    map_Y = handles.rows * map_lat / pi;
    map_X = handles.cols * map_lon / (2 * pi);
    

    % Change this to different interpolation method to see how it affects our
    % result: linear, spline, nearest...
    interpolation_method = 'cubic';
    for i = 1:3
        handles.I_transformed(:, :, i) = interp2(handles.I(:, :, i), map_X, map_Y, interpolation_method);
        % Some point maps to no where results in NAN. Use inpaint_nans to fill
        % in these points
        handles.I_transformed(:, :, i) = inpaint_nans(handles.I_transformed(:, :, i)); 
    end;
    
    imshow(uint8(handles.I_transformed));


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname] = uigetfile({'*.jpg;*.JPG;*.jpeg;*.png;*.PNG'},'Select your photosphere image');

try
    I = imread(strcat(pathname, filename));
    [rows, cols, ndims] = size(I);
    handles.rows = rows;
    handles.cols = cols;
    handles.ndims = ndims;
    [handles.X_tar, handles.Y_tar] = meshgrid(1:handles.cols, 1:handles.rows);
    handles.I = double(I);
    handles.I_transformed = double(zeros(handles.rows, handles.cols, handles.ndims));
    guidata(hObject, handles);
    updateUI(handles);
catch
end
