% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2019
% ________________________________________
% Adam Czajka, February 2016

function edgeMaps

close all
clear all

% read an image
im = rgb2gray(imread('parrot.bmp'));

% define an example bluring kernel
hSobelVertical = [-1 0 1; -2 0 2; -1 0 1];
hSobelHorizontal = hSobelVertical.';


% filter the input image
imEdgesVertical = conv2(double(im),hSobelVertical,'valid');
imEdgesHorizontal = conv2(double(im),hSobelHorizontal,'valid');

% edge maps
imEdgesTotal = sqrt(double(imEdgesVertical).^2+double(imEdgesHorizontal).^2);
imEdgesOrientation = atan2(imEdgesVertical,imEdgesHorizontal);

% to show the results (as images) we need 
% to scale absolute values to [0,255] range
% (see below for 'rescale' function)
imEdgesVertical = uint8(rescale(abs(imEdgesVertical),255));
imEdgesHorizontal = uint8(rescale(abs(imEdgesHorizontal),255));
imEdgesTotal = uint8(rescale(abs(imEdgesTotal),255));
imEdgesOrientation = uint8(rescale(abs(imEdgesOrientation),255));

% show the results
figure(1)
imshow(im)

figure(2)
imshow(imEdgesVertical)

figure(3)
imshow(imEdgesHorizontal)

figure(4)
imshow(imEdgesTotal)

figure(5)
imshow(imEdgesOrientation)
colormap('jet')
colorbar


function out = rescale(in, maxValue)
out = maxValue * (in - min(in(:))) / (max(in(:)) - min(in(:)));

