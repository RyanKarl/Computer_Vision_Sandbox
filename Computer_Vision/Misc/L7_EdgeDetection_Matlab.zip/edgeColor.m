% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2019
% ________________________________________
% Adam Czajka, February 2016

close all
clear all

% read an image
im  = imread('parrot.bmp');

% define an example bluring kernel
h = fspecial('sobel');

R = imfilter(im(:,:,1),h);
G = imfilter(im(:,:,2),h);
B = imfilter(im(:,:,3),h);

res1 = max(max(R,G),B);
res2 = imfilter(rgb2gray(im),h);

figure
imR = im;
imR(:,:,2:3) = 0;
imshow(imR)

figure
imR = im;
imR(:,:,1) = 0;
imR(:,:,3) = 0;
imshow(imR)

figure
imR = im;
imR(:,:,1:2) = 0;
imshow(imR)


figure
imshow(R)

figure
imshow(G)

figure
imshow(B)

figure
imshow(res1)

figure
imshow(res2)


