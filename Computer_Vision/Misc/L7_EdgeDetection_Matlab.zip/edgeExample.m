% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2019
% ________________________________________
% Adam Czajka, February 2016

clear all
close all

% ideal edge
x = -1:0.01:1;
y1 = sign(x);

% noisy edge
y2 = y1+0.8*rand(1,length(y1));

% approximation of a Gaussian kernel at N+1 points
mu = 0; sigma = 3; N = 7;
pd = makedist('normal',mu,sigma);
p = pdf(pd,-N:N);

% filtered version of the noisy edge
y2filtered = conv(y2,p,'valid');


%% show the results
figure(1)

subplot(3,3,1)
set(plot(x,y1),'LineWidth',2)
set(title('Ideal edge'),'FontSize',14)
axis off

subplot(3,3,2)
set(plot(x,y2),'LineWidth',2)
set(title('Real (noisy) edge'),'FontSize',14)
axis off

subplot(3,3,3)
set(plot(y2filtered),'LineWidth',2)
set(title('Gaussian-smoothed edge'),'FontSize',14)
axis off

subplot(3,3,4)
set(plot(diff(y1),'r'),'LineWidth',2)
set(title('First derivative of the ideal edge'),'FontSize',14)
axis off

subplot(3,3,5)
set(plot(diff(y2),'r'),'LineWidth',2)
set(title('First derivative of the noisy edge'),'FontSize',14)
axis off

subplot(3,3,6)
set(plot(diff(y2filtered),'r'),'LineWidth',2)
set(title('First derivative of the filtered edge'),'FontSize',14)
axis off

subplot(3,3,7)
set(plot(diff(diff(y1)),'r'),'LineWidth',2)
set(title('Second derivative of the ideal edge'),'FontSize',14)
axis off

subplot(3,3,8)
set(plot(diff(diff(y2)),'r'),'LineWidth',2)
set(title('Second derivative of the noisy edge'),'FontSize',14)
axis off

subplot(3,3,9)
set(plot(diff(diff(y2filtered)),'r'),'LineWidth',2)
set(title('Second derivative of the filtered edge'),'FontSize',14)
axis off
