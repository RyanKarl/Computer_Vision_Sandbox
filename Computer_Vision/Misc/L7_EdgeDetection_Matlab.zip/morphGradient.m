% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2019
% ________________________________________
% Adam Czajka, February 2016

close all
clear all

% read an image
I  = rgb2gray(imread('parrot.bmp'));

% make a binary image
Ibin = I > 128;

% make basic morphological operations
se = strel('disk',1);
Id  = imdilate(Ibin,se);
Ie = imerode(Ibin,se);

% calculate edges
G = abs(Id-Ie);

% show the resutls
figure
imshow(I);
title('Original image')

figure
imshow(double(Ibin));
title('Binary image')

figure
imshow(Id);
title('Dilated image')

figure
imshow(Ie);
title('Eroded image')

figure
imshow(G);
title('Detected edges')
