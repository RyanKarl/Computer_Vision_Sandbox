clear all
close all

% Let's load the zebra image, convert it to grayscale and resize:
inputImage = imresize(rgb2gray(imread('zebra.jpg')),[640 NaN]);

% And now your tasks:
%
% (a) Choose a few scales and a few orientations that give high responses; 
%     you can use the "zebra_FilterBank.m" code to investigate this
%
%     wavelengths = [w1 w2 w3 ...];
%     angles = [a1 a2 ...];
%
%     where w1, w2, ..., a1, a2, ... are wavelenghts 
%     and angles that you selected
%
%     and then just add this line to generate the Gabor filter bank:
% 
%     filterBank = gabor(wavelengths,angles);
%
% (b) Convolve your image with all these filters; use "imgaborfilt" 
%     Matlab function for this purpose; assign the result to "fileredImage"
%
% (c) Average the responses from all filters, for instance:
%  
%     fileredImage = mean(fileredImage,3);
% 
%     where "fileredImage" is the result of the "imgaborfilt" function
%
% (d) Scale the intensities in "fileredImage" matrix to the (0,255) range
% 
% (e) Apply Otsu's method to find a binarization threshold; 
%     use "graythresh" Matlab function for this purpose
% 
% (f) Binarize your image using the binarization threshold 
%     found in step (e); use "imbinarize" Matlab function for this purpose;
%     assign the result (binary image) to "binary_image" variable
% 
% (g) Play with morphological operations on the binary image calculated in 
%     step (f) to remove noise (small white blobs); you may experiment with 
%     "imerode", "imdilate", "imopen" and "imclose" Matlab functions;
%     assign the result again to "binary_image" variable (overwrite it)
% 
% (h) We are almost there! Just keep the biggest blob in your binary image:
%
%     binary_image = bwareafilt(binary_image, 1);
% 
%     and show where is our zebra (the code below will do it for you, 
%     if you kept the variable names as suggested above):
% 
%     stats = regionprops(binary_image,'Centroid','MajorAxisLength');
%
%     figure(1)
%     subplot(2,2,1)
%     imshow(inputImage)
%     title('Input image')
% 
%     subplot(2,2,2)
%     imshow(fileredImage)
%     title('Averaged filter bank response')
% 
%     subplot(2,2,3)
%     imshow(binary_image)
%     title('Binary image')
% 
%     subplot(2,2,4)
%     imComposed = uint8(255*ones(size(fileredImage,1),...
%                  size(fileredImage,2),3));
%     imComposed(:,:,1) = uint8(0.7*inputImage)+uint8(128*binary_image);
%     imComposed(:,:,2) = uint8(0.7*inputImage);
%     imComposed(:,:,3) = uint8(0.7*inputImage)+uint8(128*binary_image);
% 
%     imComposed = insertShape(imComposed,'circle',[stats.Centroid(1) ...
%                  stats.Centroid(2) stats.MajorAxisLength/2],...
%                  'LineWidth',5);
%     imshow(imComposed)
%     title('Detected zebra!')
