clear all
close all

im = imresize(rgb2gray(imread('zebra.jpg')),[640 NaN]);

% What happens if we change the filter's scale (or wavelenght) for a given orientation?
angle = 0;
for wavelength = 3:32
    
    wavelength
    
    g = gabor(wavelength,angle);
    imFilt = imgaborfilt(im,g);

    imFilt = uint8(255*(imFilt - min(imFilt(:))) / (max(imFilt(:))-min(imFilt(:))));
    
    figure(1)
    subplot(2,2,1)
    imshow(im)
    title('Grayscale image')
    
    subplot(2,2,2)
    imshow(imFilt)
    title('Filter response (magnitude)')

    subplot(2,2,3)
    t1 = real(g.SpatialKernel);
    t2 = zeros(size(im,1));
    t2(round(size(t2,1)/2-size(t1,1)/2:size(t2,1)/2+size(t1,1)/2-1),...
        round(size(t2,1)/2-size(t1,1)/2:size(t2,1)/2+size(t1,1)/2-1)) = t1;
    imshow(t2)
    title('Gabor kernel (real part) -- original size')
    
    subplot(2,2,4)
    imshow(real(g.SpatialKernel))
    title('Gabor kernel -- upscaled for better visibility')
    
    pause
    
end

% What happens if we change the filter's orientation (for a given scale)?
wavelength = 12;
for angle = 0:10:180
    
    angle
    
    g = gabor(wavelength,angle);
    imFilt = imgaborfilt(im,g);

    imFilt = uint8(255*(imFilt - min(imFilt(:))) / (max(imFilt(:))-min(imFilt(:))));
    
    figure(1)
    subplot(2,2,1)
    imshow(im)
    title('Grayscale image')
    
    subplot(2,2,2)
    imshow(imFilt)
    title('Filter response (magnitude)')

    subplot(2,2,3)
    t1 = real(g.SpatialKernel);
    t2 = zeros(size(im,1));
    t2(round(size(t2,1)/2-size(t1,1)/2:size(t2,1)/2+size(t1,1)/2-1),...
        round(size(t2,1)/2-size(t1,1)/2:size(t2,1)/2+size(t1,1)/2-1)) = t1;
    imshow(t2)
    title('Gabor kernel (real part) -- original size')
    
    subplot(2,2,4)
    imshow(real(g.SpatialKernel))
    title('Gabor kernel -- upscaled for better visibility')

    pause
    
end