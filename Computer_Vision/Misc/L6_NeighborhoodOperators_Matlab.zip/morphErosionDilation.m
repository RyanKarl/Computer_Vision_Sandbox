% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2018
% __________________________
% Adam Czajka, February 2016

close all
clear all

% read an image and select an eye region
parrotIm = rgb2gray(imread('parrot.bmp'));
parrotEye = parrotIm(180:250,290:360);
parrotEyeSmall = imresize(parrotEye,[16 16]);

% calculate an example binary image of the parrot eye
parrotEyeSmallBinary = 0.5*(1-(parrotEyeSmall>128));

% select a morphological operation and the structuring element
operation = 'dilation'; % = 'erosion';
se = ones(3,3);

[imM,imN] = size(parrotEyeSmallBinary);
[seM,seN] = size(se);
n1 = (seM-1)/2;
n2 = (seN-1)/2;
r = zeros(imN,imM);
z = zeros(imN,imM,3);

% show an animation
figure(1)
subplot(2,2,1)
imshow(parrotEyeSmallBinary)
title('Original image')


frame = 0;
for i=n1+1:imN-n1
    for j=n2+1:imM-n2
        frame = frame + 1;

        t = parrotEyeSmallBinary(-n1+i:n1+i,-n2+j:n2+j).*se;
        z(:,:,1) = parrotEyeSmallBinary;
        z(:,:,2) = parrotEyeSmallBinary;
        z(:,:,3) = parrotEyeSmallBinary;
        
        z(-n1+i:n1+i,-n2+j:n2+j,2)  = 1;

        subplot(2,2,2)
        imshow(z)
        title('How the structuring element slides ...')
        
        subplot(2,2,3)
        imshow(parrotEyeSmallBinary(-n1+i:n1+i,-n2+j:n2+j))
        title('What the structuring element "sees" ...')
        
        switch operation
            case 'dilation'
                r(i,j) = max(t(:));
            case 'erosion'
                r(i,j) = min(t(:));
        end
        
        subplot(2,2,4)
        imshow(r)
        title('Result')
        
        F(frame) = getframe(1);
        
    end
end

% uncomment this if you want to make a movie as shown in class
% movie2avi(F,'dilation.avi','fps',15)
