% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2018
% __________________________
% Adam Czajka, February 2016

close all
clear all

% read an image
im = imread('parrot.bmp');

% define an example bluring kernel
hBlur = ones(21,21)/(21*21);

% filter the input image
imBlurred = imfilter(im,hBlur,'conv','same');

% subtract the blurred image from the original input image
imDiff = imsubtract(im,imBlurred);

% add some differential image to the original image to enhance the edges
imEnhanced = im + 0.9*imDiff;

% show the results
figure(1)
subplot(2,2,1)
imshow(im)
title('Original image')

subplot(2,2,2)
imshow(imBlurred)
title('Blurred image')

subplot(2,2,3)
imshow(imDiff)
title('Differential image')

subplot(2,2,4)
imshow(imEnhanced)
title('Enhanced image')

