% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2018
% ___________________________
% Adam Czajka, September 2017

clear all
close all

% read an iris image and convert it
% to double precision
image = rgb2gray(imread('cat_low_contrast.bmp'));

% original low contrast image
figure(1)
imshow(image)

% calculate new image 
% with equalized histogram for different clip limits
CLIP_LIMITS = [0.005 0.02];
for i = 1:length(CLIP_LIMITS)
    imageEQ = adapthisteq(image,'clipLimit',CLIP_LIMITS(i),'Distribution','uniform');
    
    figure(i+1)
    imshow(imageEQ)
end

% regular (global) histogram equalization
figure(i+2)
imshow(histeq(image))