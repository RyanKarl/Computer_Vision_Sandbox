% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2018
% __________________________
% Adam Czajka, February 2016

close all
clear all

% read an image and select an eye region
parrotIm = rgb2gray(imread('parrot.bmp'));
parrotEye = parrotIm(180:250,290:360);
parrotEyeSmall = imresize(parrotEye,[16 16]);

% calculate an example binary image of the parrot eye
parrotEyeSmallBinary = 1-(parrotEyeSmall>128);

% select a morphological operation and the structuring element
operation = 'dilation'; % = 'erosion';
se = ones(3,3);

figure(1)
subplot(2,3,1)
imshow(parrotEyeSmallBinary)
title('original image I')

% morphological closing = dilation(erosion(image))
I1 = imdilate(parrotEyeSmallBinary,se);
I2 = imerode(I1,se);

subplot(2,3,2); imshow(I1); title('dilation(I)')
subplot(2,3,3); imshow(I2); title('erosion(dilation(I))')

% morphological opening = erosion(dilation(image))
I1 = imerode(parrotEyeSmallBinary,se);
I2 = imdilate(I1,se);

subplot(2,3,5); imshow(I1); title('erosion(I)')
subplot(2,3,6); imshow(I2); title('dilation(erosion(I))')

