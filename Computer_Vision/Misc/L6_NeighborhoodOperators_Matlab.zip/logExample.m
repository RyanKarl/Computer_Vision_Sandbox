% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame, Fall 2018
% __________________________
% Adam Czajka, February 2016

close all
clear all

% read and scale an image
im = rgb2gray(imread('parrot.bmp'));

% define LoG kernel
ghSize = 15;
ghSigma = 2;
gh = fspecial('log', ghSize, ghSigma);

% convolve the image with the LoG kernel 'gh'
imFiltered = imfilter(double(im),gh,'conv','same');

% scale the resulting image intensity to the range
imFilteredScaled = uint8(255*(imFiltered-min(imFiltered(:))) / (max(imFiltered(:)) - min(imFiltered(:))));

% show the results
figure(1)
imshow(im)
title('Original image')

figure(2)
mesh(gh)
title('LoG kernel')

figure(3)
imshow(imFilteredScaled)
title('Filtered image')

