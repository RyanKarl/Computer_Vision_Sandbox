% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame
% ________________________________________________________________
% Adam Czajka, February 2016

close all
clear all

% read an image
I = rgb2gray(imread('pills.png'));
figure; imshow(I);

% since our pills are bright, prepare negative image (our pills will be now
% catchment basins)
Inegative = 255-I;
figure; imshow(Inegative);

% run a watershed algorithm on the original image
L = watershed(Inegative,8);

BW = uint8(ones(size(I,1),size(I,2)));
BW(L==0) = 0;
Ilabels = label2rgb(L,'jet',[.5 .5 .5]);
Result = imadd(uint8(I),255*(1-BW));
figure; imshow(Ilabels); title('Resulting labels')
figure; imshow(Result); title('Boundaries on the original image (quite bad ...)')


% since we are not happy with the previous result, let's suppress small 
% minima; here "small" means less than image standard deviation
Isuppressed = imhmin(Inegative,std(double(Inegative(:))));

L = watershed(Isuppressed,8);
BW = uint8(ones(size(I,1),size(I,2)));
BW(L==0) = 0;
Ilabels = label2rgb(L,'jet',[.5 .5 .5]);
Result = imadd(uint8(I),255*(1-BW));
figure; imshow(Ilabels); title('Resulting labels')
figure; imshow(Result); title('Boundaries on the original image (looks better ...)')


% show different pills in different colors (just for fun) 
level = graythresh(I);
BW = im2bw(I,level);
BW3(:,:,1)=BW;
BW3(:,:,2)=BW;
BW3(:,:,3)=BW;
figure; imshow(uint8(Ilabels).*uint8(BW3))
