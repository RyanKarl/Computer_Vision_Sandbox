% Computer Vision Course (CSE 40535/60535)
% University of Notre Dame
% ________________________________________________________________
% Adam Czajka, February 2016

close all
clear all

% read an image and filter out the noise seen on the sky
I = imread('1.bmp');
I2 = medfilt2(I,[7 7]);

% select some initial shape
figure(1)
imshow(I)
title('Click to select initial contour location. Double-click to confirm.')
mask = roipoly;

% find an optimal shape using Chan-Vese algorithm

for i=1:50
    maxIterations = i;
    bw = activecontour(I2, mask, maxIterations, 'Chan-Vese','SmoothFactor',1.5,'ContractionBias',0);
    
    % show the result on the input image
    figure(1)
    hold on
    imagesc(I)
    colormap gray
    set(gca,'YDir','reverse')
    visboundaries(bw,'Color','r');
    hold off
    
end
